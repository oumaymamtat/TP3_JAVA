package projetreferences;

public class Projetreferences {
    public static void main(String[] args) {
       Point point = new Point (5,6) ;
      point.décrémenter(); 
      point.raz(); 
      point.incrémenter();
      point.saisir();
      System.out.println(point);
      Nombre entier  = new Nombre(12);
      entier.saisir (); 
      entier.afficher();
      entier.incrémenter(); 
      entier.afficher();
      entier.décrémenter(); 
      entier.afficher();
      entier.raz(); 
      entier.afficher();
      // pour tester la référence à la méthode
      Incrementable incr = Nombre::incrément;
      incr.incrément(5,11);
    }
    
}
