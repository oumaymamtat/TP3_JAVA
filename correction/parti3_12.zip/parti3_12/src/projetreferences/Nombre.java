package projetreferences;


import java.util.Scanner;

public class Nombre {
private int valeur;
public Nombre (int valeur){
    this.valeur = valeur;
}
public void saisir () {
System.out.println("Donnez un entier: ");
Scanner sc = new Scanner(System.in);
valeur = sc.nextInt();
}
public void afficher () {
System.out.println("Entier = "+valeur);
}
public void incrémenter () { valeur++; }
public void décrémenter () { valeur--; }
public void raz () { valeur = 0; }
// pour tester la référence à la méthode
public static void incrément(int val ,int i){
    if (val%2==0)
    System.out.println(val+i);
    else System.out.println(val+2*i);
}
   
}
