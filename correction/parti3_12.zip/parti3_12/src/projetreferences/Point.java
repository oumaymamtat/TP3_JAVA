package projetreferences;


import java.util.Scanner;

public class Point {
private int x;
private int y;
public Point(int x, int y){
    this.x=x; this.y=y;}

public void incrémenter () {
 x++; y++;  System.out.println("["+x + " "+y+"]");}
public void décrémenter () { 
x--; y--; System.out.println("["+x + " "+y+"]");}
public void raz () { 
x = 0; y = 0;  System.out.println("["+x + " "+y+"]");} 
public void saisir () {
System.out.println("Donnez l'abscisse: ");
Scanner sc = new Scanner(System.in);
x = sc.nextInt();
System.out.println("Donnez l'ordonnée: ");
y = sc.nextInt();
}
public String toString () {
return ("["+x + " "+y+"]");}
}



