package projetreferences;

public interface Incrementable {
    // pour tester la référence à la méthode
    void incrément (int val, int i);
}
