package projetreferences;

public interface Modifiable {
    void incrémenter ();
     void décrémenter ();
     
}
