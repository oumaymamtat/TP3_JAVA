package projetInitial;

public interface Modifiable {
int incrémenter (int val ,int inc);
int décrémenter (int val,int inc);
int raz (int val);
  }
