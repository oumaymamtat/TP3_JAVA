package proj2;

public interface Modifiable {
void incrémenter ();
void décrémenter ();
void raz ();

}
