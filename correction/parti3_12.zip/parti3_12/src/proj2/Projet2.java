package proj2;


import java.util.Scanner;

public class Projet2 {
    public static void main(String[] args) {
 Modifiable point = new Modifiable () {
private int x = 5;
private int y = 6;
@Override
public void incrémenter () {
x++; y++;
System.out.println("["+x + " "+y+"]");}
@Override
public void décrémenter () { x--; y--;
System.out.println("["+x + " "+y+"]");}
@Override
public void raz () { x = 0; y = 0;
System.out.println("["+x + " "+y+"]");}
};
point.décrémenter(); 
point.raz(); 
point.incrémenter();

Nombre entier = new Nombre () {
private int valeur = 0;
public void saisir () {
System.out.println("Donnez un entier: ");
Scanner sc = new Scanner(System.in);
valeur = sc.nextInt();
}
public void afficher () {
System.out.println("Entier = "+valeur);
}
public void incrémenter () { valeur++; }
public void décrémenter () { valeur--; }
public void raz () { valeur = 0; }
};
entier.saisir (); 
entier.afficher();
entier.incrémenter(); 
entier.afficher();
entier.décrémenter(); 
entier.afficher();
entier.raz(); 
entier.afficher();


    }
    
}
