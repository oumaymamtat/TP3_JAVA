package proj2;

public abstract class Nombre implements Modifiable {
public abstract void saisir ();
public abstract void afficher ();
  
}
