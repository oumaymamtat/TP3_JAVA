package projetLambda;

public interface Decrementable {
   int décrémenter (int val,int dec);
}
