package projetLambda;


import java.util.Scanner;
public class Principal {
public static int traiter (int a, int b, Incrementable incr){
    return incr.incrémenter(a, b);}

public static void main(String[] args) {
  Incrementable incr = (val,inc)-> {if (val%2== 0)return val+inc; else return val+2*inc;};
  Decrementable decr = (val,dec)-> val-dec;
  Resetable rez = val -> val=0;
  Scanner sc = new Scanner(System.in);
  System.out.println("Saisir un entier:");
  int valeur = sc.nextInt();
  valeur = incr.incrémenter(valeur, 3);
  System.out.println("valeur entier: "+valeur);
  valeur = decr.décrémenter(valeur, 5);
  System.out.println("valeur entier: "+valeur);
  valeur=rez.raz(valeur);
  System.out.println("valeur entier: "+valeur);
  Scanner sc1 = new Scanner(System.in);
  System.out.println("Saisir un entier:");
  int valeur1 = sc1.nextInt();
  valeur1= traiter(valeur1,3,(a,b)-> {if (a%2==0) return a+b; else return a+2*b;});
  System.out.println("valeur entier: "+valeur1);
}}
