package projetLambda;

public interface Resetable {
   int raz (int val);
}
