package projetLambda;

public interface Incrementable {
    int incrémenter (int val ,int inc);
}
