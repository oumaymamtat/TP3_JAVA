package exception;


import java.io.IOException;

import java.util.Scanner;

public class main_test {

	private static Scanner scan;

	public static void main(String[] args) throws ErreurAjout,ErreurSuppression, ErreurRang {
		
        
                           TableSalaries table=new TableSalaries();
		
         
              scan = new Scanner(System.in);
		
		 boolean quit = false;
         
		 do { /***********Menu*****************/
				System.out.println("******Menu******");
				System.out.println("Veuillez choisir � partir du menu");
				System.out.println("a . Ajouter un salari�");
				System.out.println("b . Supprimer un salari�");
				System.out.println("c . Afficher les salari�s");
				System.out.println("d . Total des payes � verser");
				System.out.println("e . Quitter");
			

                   String val=scan.nextLine();

			char x=val.charAt(0);

		switch (x) {

		case 'a':
		
			System.out.println("Tapez D pour Directeur");
			System.out.println("Tapez V pour Vendeur");
			System.out.println("Tapez E pour Employee");
			

                   Scanner s1 = new Scanner(System.in);

			String choix=s1.nextLine();

			char c=choix.charAt(0);

					if (c=='D')
					{
						System.out.println("Vous avez choisi d'ajouter un directeur");
						System.out.println("Veuillez saisir le nom");
						String nom=s1.nextLine();
						
						System.out.println("Veuillez saisir la matricule");
						int matricule=s1.nextInt();
						
						System.out.println("Veuillez saisir le salaire");
				
						double salaire=s1.nextDouble();
						
						System.out.println("Veuillez saisir la prime");
						
						double prime=s1.nextDouble();
						
				
              try {  table.ajouterSalarie(new Directeur(nom, matricule, salaire, prime));
						
                                     System.out.println("Directeur ins�r�");}

				catch ( ErreurAjout e)		
					
                                    {  System.out.println(" le tableau est plein");}



                                                           }
				
					else if (c=='V')
					{
						System.out.println("Vous avez choisi d'ajouter un Vendeur");
						
						System.out.println("Veuillez saisir le nom");
						String nom=s1.nextLine();
						
						System.out.println("Veuillez saisir la matricule");
						int matricule=s1.nextInt();
						
						System.out.println("Veuillez saisir le nombre d'heures, ");
						int nbre_heure=s1.nextInt();
						
						System.out.println("Veuillez saisir le prix de l'heure");
						double prix_heure=s1.nextDouble();
						
						System.out.println("Veuillez saisir le prix de ventes");
						double ventes=s1.nextDouble();
						
					try { table.ajouterSalarie(new Vendeur(nom, matricule, nbre_heure, prix_heure, ventes));
					
                                        	System.out.println("Vendeur ins�r�"); }

                                     catch ( ErreurAjout e)		
					
                                    {  System.out.println(" le tableau est plein");}

					}
					
					else if (c=='E')
					{
						System.out.println("Vous avez choisi d'ajouter un Employee");
						
						System.out.println("Veuillez saisir le nom");
						String nom=s1.nextLine();
						
						System.out.println("Veuillez saisir la matricule");
						int matricule=s1.nextInt();
						
						System.out.println("Veuillez saisir le nombre d'heures, ");
						int nbre_heure=s1.nextInt();
						
						System.out.println("Veuillez saisir le prix de l'heure");
						double prix_heure=s1.nextDouble();
											
					try { table.ajouterSalarie(new Employe(nom, matricule, nbre_heure, prix_heure));
						
                                                      System.out.println("Employe ins�r�");}

                                        catch ( ErreurAjout e)		
					
                                    {  System.out.println(" le tableau est plein");}

					}
			
					//table.afficheInfo();
			break;
		
		
		case 'b':
			
			Scanner scan1= new Scanner(System.in);
		
			try {
				
				System.out.print("Tapez le rang ");
				int i=scan1.nextInt();
				table.supprimerEmp(i);
			} 
			catch (ErreurSuppression e) {
				System.out.println("/********erreur********");
				System.out.println("Le tableau est vide");
				System.out.println("/**********************");
				e.printStackTrace();
			}
			catch (ErreurRang e) {
				System.out.println("/********erreur********");
				System.out.println("Rang inexistant");
				System.out.println("/**********************");
				e.printStackTrace();  // vider la pile d'erreur.
			} 
			
			
			
		
			break;
		
		
		case 'c':
		
			
			table.afficheInfo();
			break;
		
		
		case 'd':
			
			System.out.println("la total des payes � verser est:  "+table.CalculTotalPay());
			break;
		
		case 'e':
			
			System.exit('e');
			break;
		
		default: System.out.println("Choix invalide");
			break;
		}
		
		 } while (!quit);
         System.out.println("That's All, See you soon");
	}

}
