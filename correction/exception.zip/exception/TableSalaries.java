package exception;


public class TableSalaries {
	
	private Salarie[] salarie;
	private int nbreSalarie;
    private final static int max_salarie = 200;
    
    /************************constructeur************************/
    public TableSalaries() {
    	salarie = new Salarie[max_salarie];
    	nbreSalarie = 0;
    }
    /******************ajouter salarie***************************/
    public void ajouterSalarie(Salarie salarie) throws ErreurAjout{
		 ++nbreSalarie;
	        if (nbreSalarie > max_salarie) throw new ErreurAjout("Vous avez d�pass� le nombre permi");//******
	        	this.salarie[nbreSalarie - 1] = salarie;
	        	
	       
	}
	
	/********************afficher tous les salaries******************/
	public void afficheInfo(){
		for(int i=0; i<this.nbreSalarie;i++)
		{
			this.salarie[i].afficherSalarie();
		}
		
	}
	
	
	
	/***********************calcul Total des paye***************/
	public double CalculTotalPay()
	{
		double sommePay=0;
		for(int i=0; i<nbreSalarie;i++)
		{
			sommePay=salarie[i].calculerSalaire()+sommePay;
		}
		return sommePay;
	}
	/***********************************************************/
	
	/*************************Delete function
	 * @throws ErreurRang 
	 * @throws ErreurSuppression *****************/
	public void supprimerEmp(int rang) throws ErreurSuppression, ErreurRang
	{	
		if(this.nbreSalarie==0)throw new ErreurSuppression("Erreur, le tableau est vide");//************
		if((rang<0)||(rang>=this.nbreSalarie))throw new ErreurRang("Erreur, veuillez saisir un rang valide");//********
		
		else{
		int i = 0;
		while(i>=0 && i<this.nbreSalarie)
		{
			if(rang==i)
			{
				this.salarie[i]=this.salarie[i+1];
				this.nbreSalarie=this.nbreSalarie-1;
			}
			i++;
		}}
	
	}
	

	
}
