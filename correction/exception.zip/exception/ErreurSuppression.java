package exception;




public class ErreurSuppression extends Exception {
	
	

	public ErreurSuppression(String message) {
	    super(message);
	  }

}
