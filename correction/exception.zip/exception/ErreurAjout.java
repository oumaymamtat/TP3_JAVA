





package exception;

public class ErreurAjout extends Exception {


	
	public ErreurAjout(String message) {
	    super(message);
	  }
	  
	/*  ----------ou_bien -----------------
	  
           public ErreurAjout() {
		  
               System.out.println("le tableau est plein");
		  
                   }*/
	 

}
