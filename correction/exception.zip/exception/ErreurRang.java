package exception;


public class ErreurRang extends Exception {

	public ErreurRang(String message) {
	    super(message);
	  }

}
